# tos-app-market
appmarket是部署在tdc上的应用市场和开发平台微服务。

* golang version >=1.11

## Deployment
### 开发环境
```bash
mkdir -p $GOPATH/src/transwarp.io/
cd $GOPATH/src/transwarp.io/
git clone http://172.16.1.41:10080/zhaoyue0513/go-walmclient.git
cd go-walmclient
git checkout 2.2
cd ..
git clone http://172.16.1.41:10080/nonetheless/go-harborclient.git
git checkout 1.9.0
cd ..
git clone http://172.16.1.41:10080/TDC/hamurapi-clients.git
cd hamurapi-clients/golang/hamurapi-golang-client/
go mod init
cd ../../..
mv go-walmclient walmcli
mv go-harborclient harborcli
mkdir -p $GOPATH/src/transwarp/
cd $GOPATH/src/transwarp/
git clone http://172.16.1.41:10080/app/tos-app-market.git
git checkout master
cd tos-app-market
go mod download  #transwarp包下的依赖需要手动下载，参见go.mod
go mod vendor
```
安装swagger:

Linux
```bash
# Install go swagger
# https://github.com/go-swagger/go-swagger

latestv=$(curl -s https://api.github.com/repos/go-swagger/go-swagger/releases/latest | jq -r .tag_name)
sudo curl -o /usr/local/bin/swagger -L'#' https://github.com/go-swagger/go-swagger/releases/download/$latestv/swagger_$(echo `uname`|tr '[:upper:]' '[:lower:]')_amd64
sudo chmod +x /usr/local/bin/swagger
```

Mac
```bash
brew install go-swagger
```
生成swagger：
```bash
make go-swagger  
```
运行appmarket：
```bash
go run main.go serv --config $APPMARKET-CONFIG
```
数据库migrate
```bash
gorm-migrate migrate -d migration/ -p transwarp/tos-app-market/migration
```

数据库回滚：
```bash
go run main.go database downgrade -d postgres -u "host=172.16.3.231 port=31079 user=postgres password=postgres123 dbname=tos_app_market sslmode=disable"
```

kubeconfig设置：
```bash
# get secret token form cluster
sudo cp -r . /var/run/secrets/kubernetes.io/serviceaccount/
```
url:http://0.0.0.0:9001/market/api/v1/appstore/terminal/tty/?session-id=sshsi88q7u3nyllw8jiwkzp6fl42za5y

### 配置
appmarket 依赖于 walmv2，postgresql，harbor

参考 app-market.yaml

### test
单元测试
```bash
make test
```
e2e测试
```bash
make e2e
```

## Install
### 打包应用市场
打包appmarket-package
```bash
make package
```
应用市场会生成一个appmarket-package:<tdc-version> 的image包含了需要上传的chart和walm，postgres，chartmuseum，appmarket的镜像，以及安装脚本deploy.sh

### 部署应用市场
手动安装应用市场
```bash
export NAMESPACE=appmarket
export REGISTRY_ADDR=<registry_addr>
docker pull ${APPMARKET_IMG}
APPMARKET_CONTAINER=`docker create ${APPMARKET_IMG}`
docker cp ${APPMARKET_CONTAINER}:/root/appmarket-package.tar .
tar xvf appmarket-package.tar
bash appmarket-package/deploy.sh <tdc-version>
```
自动安装应用市场

TODO


